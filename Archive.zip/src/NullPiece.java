//This file contains the NullPiece class which represents the null value of th piece
public class NullPiece extends Piece {
    public NullPiece() {
        super(" ");

    }
}
