//This files contains UseableItems super class which represents all the useable items
public class UseableItems extends Item {
    public UseableItems(int itemId, String itemName, int itemCost, int requiredLevel) {
        super(itemId, itemName, itemCost, requiredLevel);
    }
}
