//This file contains the Game class which is the super class of all the board games
public abstract class Game{
    public abstract void run();
}
