//This file contains the Main class and main method
public class Main {


    public static void main(String[] args) {

        Game game = new RPGGame();
        game.run();

    }
}