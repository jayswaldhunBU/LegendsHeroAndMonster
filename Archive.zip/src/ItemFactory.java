//This file contains the ItemFactory class which has abstract method to create items
public abstract class ItemFactory {

   abstract Item createItem(int itemId);
    }

