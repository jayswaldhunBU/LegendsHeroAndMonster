//This files contains UseableItemsFactory super class which represents all the useable items
public abstract class UseableItemsFactory extends ItemFactory {
    abstract Item createItem(int itemId);
}

