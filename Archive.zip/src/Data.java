//Super class of all the data saved in game
abstract class Data {
    public abstract void displayData();
}

